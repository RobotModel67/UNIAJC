/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.uniajc.beatrix;

import co.edu.uniajc.beatrix.entities.Facultad;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

/**
 *
 * @author SERVER
 */
public class LoadFileServlet extends HttpServlet {

    Repository repo;

    @Override
    public void init() throws ServletException {
        repo = new Repository();
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        System.out.println("LoadFileServlet processRequest...");

        // Cargar el archivo 
        boolean isMultipartContent = ServletFileUpload.isMultipartContent(request);
        FileItemFactory factory = new DiskFileItemFactory();
        ServletFileUpload upload = new ServletFileUpload(factory);

        System.out.println("LoadFileServlet uploaded?...");
        Facultad facultad = null;

        try {
            List<FileItem> fields = upload.parseRequest(request);
            Iterator<FileItem> it = fields.iterator();
            System.out.println("LoadFileServlet parseRequest(?...");

            if (!it.hasNext()) {
                return;
            }
            while (it.hasNext()) {
                FileItem fileItem = it.next();
                boolean isFormField = fileItem.isFormField();
                if (isFormField) {
                    if (fileItem.getFieldName().equals("facultad")) {
                        facultad = repo.getFacultad(Long.parseLong(fileItem.getString()));
                    }
                } else {
                    procesarArchivo(facultad, fileItem.getInputStream());
                }
            }

        } catch (FileUploadException e) {
            e.printStackTrace();
        }
        
        RequestDispatcher rd = request
                .getRequestDispatcher("/contratos.jsp");
        
        rd.forward(request, response);
        
    }

    private void procesarArchivo(Facultad facultad, InputStream inputStream) {
        //repo.deleteCarga(facultad, periodo);
        //Carga carga = repo.letCarga(facultad, periodo);

        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
        try {
            String line;
            String[] fields;
            int header = 0;

            repo.deleteRegistroAll();
            /*
            Docente d = null;
            Asignacion a = null;
            Materia m = null;
            Grupo g = null;
            ValorHora v = null;
            Categoria c = null;
             */
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
                header++;

                if (header < 2) {
                    continue;
                }

                fields = line.split("\t");
                if (fields.length < 14) {
                    continue;
                }
                String sContrato = fields[0].trim();
                String sDocumento = fields[1].trim().trim().replace(".", "").replace(",", "");
                String sTipo_documento = fields[2].trim();
                String sCiudad_documento = fields[3].trim();
                String sDocente = fields[4].trim();
                String sCategoria = fields[5].trim();
                String sAsignatura = fields[6].trim();
                String sGrupo = fields[7].trim();
                String sHoras_semestre = fields[8].trim();
                String sObservarciones = fields[9].trim();
                String sValor_hora = fields[10].trim();
                String sFecha_inicio = fields[11].trim();
                String sFecha_final = fields[12].trim();
                String sCuotas = fields[13].trim();
                
                repo.setRegistro(
                        facultad.getId(), 
                        sContrato,
                        sDocumento,
                        sTipo_documento,
                        sCiudad_documento,
                        sDocente, 
                        sCategoria, 
                        sAsignatura, 
                        sGrupo,
                        sHoras_semestre,
                        sObservarciones,
                        sValor_hora,
                        sFecha_inicio,
                        sFecha_final,
                        sCuotas
                );
                /*
                String sDocumento = fields[0];
                String sCiudad = fields[1];
                String sDocente = fields[2];
                String sAsignatura = fields[4];
                String sGrupo = fields[5];
                String sHoras = fields[6];
                String sCategoria = fields[3];
                String sObservaciones = "";
                String sTipo = "TECNOLOGIA";

                if (fields.length == 8) {
                    sObservaciones = fields[7];
                }
                d = repo.letDocente(sDocumento, sDocente, sCategoria, sCiudad);
                m = repo.letMateria(sAsignatura);
                 */
                // aqui hay que definir el tipo de materia en funcion de su descripcion
                // sAsignatura
                /*
                if (sAsignatura.toUpperCase().startsWith("ASESOR")) {
                    sTipo = "ASESORIA";
                } else if (sAsignatura.toUpperCase().startsWith("DIPLOM")) {
                    sTipo = "DIPLOMADO";
                }
                 */
 /*
                if (sObservaciones.toUpperCase().contains("ASESOR")) {
                    sTipo = "ASESORIA";
                } else if (sObservaciones.toUpperCase().contains("DIPLOM")) {
                    sTipo = "DIPLOMADO";
                }

                v = repo.letValorHora(facultad, d.getCategoria(), sTipo);
                System.out.println(v);

                if (a == null || a.getDocente() != d) {
                    a = repo.letAsignacion(carga, d);
                    //System.out.println(v.getValor());
                }
                g = repo.letGrupo(sGrupo, a, m, Float.parseFloat(sHoras), v.getValor(), sTipo, sObservaciones);
                 */
                //System.out.println(g);
                //g = repo.letGrupo(sGrupo, a, m, Integer.parseInt(sHoras), sObservaciones);
            }
            reader.close();
        } catch (IOException ex) {
            Logger.getLogger(LoadFileServlet.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
