/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.uniajc.beatrix;

import co.edu.uniajc.beatrix.entities.Facultad;
import co.edu.uniajc.beatrix.entities.Registro;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

/**
 *
 * @author SERVER
 */
public class Repository {

    private EntityManager em;
    private SimpleDateFormat df_amd = new SimpleDateFormat("yyyy-MM-dd");

    public Repository() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("BEATRIX");
        em = emf.createEntityManager();
    }

    public List<Facultad> getFacultadAll() {
        Query query = em.createQuery("SELECT f FROM Facultad f");
        return (List<Facultad>) query.getResultList();
    }

    public Facultad getFacultad(Long id) {
        Facultad f = null;
        try {
            f = (Facultad) em.createQuery("SELECT f FROM Facultad f WHERE f.id = :id")
                    .setParameter("id", id)
                    .getSingleResult();
        } catch (Exception e) {
            System.out.println("Error getFacultad: " + e.getMessage());
        }
        return f;
    }

    public List<Registro> getRegistroAll() {
        Query query = em.createQuery("SELECT r FROM Registro r");
        return (List<Registro>) query.getResultList();
    }

    public void deleteRegistroAll() {
        EntityTransaction transaction = em.getTransaction();
        transaction.begin();
        Query q1 = em.createNativeQuery("DELETE FROM Registro");
        q1.executeUpdate();
        transaction.commit();
    }

    void setRegistro(Long id_facultad, String sContrato, String sDocumento, String sTipo_documento, String sCiudad_documento,
            String sDocente, String sCategoria, String sAsignatura, String sGrupo, String sHoras_semestre,
            String sObservarciones, String sValor_hora, String sFecha_inicio, String sFecha_final, String sCuotas) {

        EntityTransaction transaction = em.getTransaction();
        transaction.begin();

        Registro registro = new Registro();

        try {
            registro.setId_facultad(id_facultad);
            registro.setNumero_contrato(sContrato);
            registro.setDocumento(sDocumento);
            registro.setTipo_Documento(sTipo_documento);
            registro.setCiudad_documento(sCiudad_documento);
            registro.setDocente(sDocente);
            registro.setCategoria(sCategoria);
            registro.setAsignatura(sAsignatura);
            registro.setGrupo(sGrupo);
            registro.setHoras_semestre(Float.parseFloat(sHoras_semestre));
            registro.setObservarciones(sObservarciones);
            registro.setValor_hora(Integer.parseInt(sValor_hora));
            registro.setFecha_inicio(df_amd.parse(sFecha_inicio));
            registro.setFecha_final(df_amd.parse(sFecha_final));
        } catch (ParseException ex) {
            Logger.getLogger(Repository.class.getName()).log(Level.SEVERE, null, ex);
            transaction.rollback();
        }

        registro.setCuotas(Float.parseFloat(sCuotas));

        em.persist(registro);
        transaction.commit();

    }

    public List<Registro> getRegistroSameById(Long id) {
        Registro registro = this.getRegistroById(id);
        String documento = registro.getDocumento();
        List<Registro> registros = null;

        try {
            registros = (List<Registro>) em.createQuery("SELECT r FROM Registro r WHERE r.documento = :documento")
                    .setParameter("documento", documento)
                    .getResultList();
        } catch (Exception e) {
            System.out.println("Error getRegistroSameById");
        }
        return registros;
    }

    public Registro getRegistroById(Long id) {
        Registro registro = null;
        //try {
        registro = (Registro) em.createQuery("SELECT r FROM Registro r WHERE r.id = :id")
                .setParameter("id", id)
                .getSingleResult();
        //} catch (Exception e) {
        //    System.out.println("Error getRegistroById");
        //}
        return registro;

    }
}
