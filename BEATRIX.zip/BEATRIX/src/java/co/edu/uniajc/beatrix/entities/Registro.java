/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.uniajc.beatrix.entities;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import static javax.persistence.TemporalType.DATE;

/**
 *
 * @author jlvalencia
 */
@Entity()
@Table(name = "registro")
public class Registro {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_registro")
    Long id;

    @Column(name = "id_facultad")
    Long id_facultad;

    @Column(name = "numero_contrato")
    String numero_contrato;

    @Column(name = "documento")
    String documento;

    @Column(name = "tipo_documento")
    String tipo_documento;

    @Column(name = "ciudad_documento")
    String ciudad_documento;

    @Column(name = "docente")
    String docente;

    @Column(name = "categoria")
    String categoria;
    
    @Column(name = "asignatura")
    String asignatura;

    @Column(name = "grupo")
    String grupo;
    
    @Column(name = "horas_semestre")
    Float horas_semestre;
    
    @Column(name = "observarciones")
    String observarciones;

    @Column(name = "valor_hora")
    Integer valor_hora;

    @Column(name = "fecha_inicio")
    @Temporal(DATE)            
    Date fecha_inicio;

    @Column(name = "fecha_final")
    @Temporal(DATE)            
    Date fecha_final;
    
    @Column(name = "cuotas")
    Float cuotas;        
    
    public Registro() {

    }
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId_facultad() {
        return id_facultad;
    }

    public void setId_facultad(Long id_facultad) {
        this.id_facultad = id_facultad;
    }

    public String getNumero_contrato() {
        return numero_contrato;
    }

    public void setNumero_contrato(String numero_contrato) {
        this.numero_contrato = numero_contrato;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public String getTipo_documento() {
        return tipo_documento;
    }

    public void setTipo_Documento(String tipo_documento) {
        this.tipo_documento = tipo_documento;
    }

    public String getCiudad_documento() {
        return ciudad_documento;
    }

    public void setCiudad_documento(String ciudad_documento) {
        this.ciudad_documento = ciudad_documento;
    }

    public String getDocente() {
        return docente;
    }

    public void setDocente(String docente) {
        this.docente = docente;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getAsignatura() {
        return asignatura;
    }

    public void setAsignatura(String asignatura) {
        this.asignatura = asignatura;
    }

    public String getGrupo() {
        return grupo;
    }

    public void setGrupo(String grupo) {
        this.grupo = grupo;
    }

    public Float getHoras_semestre() {
        return horas_semestre;
    }

    public void setHoras_semestre(Float horas_semestre) {
        this.horas_semestre = horas_semestre;
    }

    public String getObservarciones() {
        return observarciones;
    }

    public void setObservarciones(String observarciones) {
        this.observarciones = observarciones;
    }

    public Integer getValor_hora() {
        return valor_hora;
    }

    public void setValor_hora(Integer valor_hora) {
        this.valor_hora = valor_hora;
    }

    public Date getFecha_inicio() {
        return fecha_inicio;
    }

    public void setFecha_inicio(Date fecha_inicio) {
        this.fecha_inicio = fecha_inicio;
    }

    public Date getFecha_final() {
        return fecha_final;
    }

    public void setFecha_final(Date fecha_final) {
        this.fecha_final = fecha_final;
    }

    public Float getCuotas() {
        return cuotas;
    }

    public void setCuotas(Float cuotas) {
        this.cuotas = cuotas;
    }

    public String getTipo_documento_abreviado() {
        String result = "";
        String[] words = this.tipo_documento.split(" ");
        for (String word : words) {
            if (!word.toLowerCase().equals("de")) {
                result += word.substring(0,1).toUpperCase() + ".";
            }
        }
        return result;
    }
    
    
}
